"""
Version information for ClaritySpectra.
This is the single source of truth for the application version.
"""

__version__ = "2.1.0"
__author__ = "Aaron Celestian, Ph.D."
__copyright__ = "© 2025 Aaron Celestian. All rights reserved" 