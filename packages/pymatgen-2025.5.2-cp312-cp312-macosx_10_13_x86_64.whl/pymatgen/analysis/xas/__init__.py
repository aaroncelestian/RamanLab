"""Package for analysis of X-ray Absorption Spectroscopy."""
