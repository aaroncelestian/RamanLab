"""The borg package contains modules that assimilate large quantities of data into
pymatgen objects for analysis.
"""
